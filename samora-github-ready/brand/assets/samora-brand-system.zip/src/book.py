"""Build the Samora brand book as one self-contained HTML file."""
import base64, os, math
import palette as P
import marks as M

NM = "/home/claude/logo/node_modules"
HERE = "/home/claude/brand"


def b64font(path):
    return base64.b64encode(open(path, "rb").read()).decode()


FACES = "".join(
    f"@font-face{{font-family:'Archivo';font-weight:{w};font-style:normal;font-display:block;"
    f"src:url(data:font/woff2;base64,{b64font(f'{NM}/@fontsource/archivo/files/archivo-latin-{w}-normal.woff2')}) format('woff2');}}"
    for w in (400, 500, 600))

TOKENS = open(f"{HERE}/samora-tokens.css").read()

# ---------------------------------------------------------------- helpers
def swatch(name, hexv, note=""):
    return (f'<div class="sw"><div class="sw-chip" style="background:{hexv}"></div>'
            f'<div class="sw-name">{name}</div><div class="sw-hex">{hexv}</div>'
            f'<div class="sw-note">{note}</div></div>')


def sand_row():
    return "".join(swatch(f"sand {k}", v) for k, v in P.SAND.items())


def role_table(roles, label):
    rows = "".join(
        f'<tr><td><span class="dot-sq" style="background:{v}"></span> --c-{k}</td>'
        f'<td class="mono">{v}</td></tr>' for k, v in roles.items())
    return f'<table class="table tbl-tight"><thead><tr><th>{label}</th><th>Value</th></tr></thead><tbody>{rows}</tbody></table>'


def contrast_table():
    rows = ""
    for r in P.audit():
        verdict = "pass" if r["pass_"] else "fail"
        rows += (f'<tr><td>{r["mode"]}</td><td>{r["fg"]}</td><td>{r["bg"]}</td>'
                 f'<td class="num">{r["ratio"]:.2f}:1</td><td class="num">{r["minimum"]:.1f}</td>'
                 f'<td><span class="tag tag--{"verified" if r["pass_"] else "risk"}">{verdict}</span></td>'
                 f'<td class="muted">{r["why"]}</td></tr>')
    return ('<table class="table"><thead><tr><th>Mode</th><th>Foreground</th><th>Background</th>'
            '<th class="num">Measured</th><th class="num">Minimum</th><th>Result</th><th>Where</th>'
            f'</tr></thead><tbody>{rows}</tbody></table>')


TYPE_ROWS = [
    ("Display", "3xl", 44, 600, "-0.01em", 1.15, "One per page at most. Covers, hero, the number that matters."),
    ("H1", "2xl", 34, 600, "-0.01em", 1.15, "Page title."),
    ("H2", "xl", 26, 600, "-0.01em", 1.2, "Section."),
    ("H3", "lg", 20, 600, "0", 1.25, "Subsection, card title."),
    ("Body large", "md", 16, 400, "0", 1.55, "Intro paragraphs, empty states."),
    ("Body", "sm", 14, 400, "0", 1.55, "Default. Everything unless stated."),
    ("Dense", "xs", 13, 400, "0", 1.45, "Buttons, form labels, dense panels."),
    ("Table", "2xs", 12, 400, "0", 1.35, "Table cells. Tabular numerals always on."),
    ("Micro", "3xs", 11, 600, "0.10em", 1.2, "Uppercase labels. The only place caps are allowed."),
]


def type_specimen():
    out = ""
    for name, tok, px, wt, tr, lh, why in TYPE_ROWS:
        out += (f'<div class="ty-row"><div class="ty-meta"><div class="ty-name">{name}</div>'
                f'<div class="ty-spec mono">{px}px / {wt} / {tr} / {lh}</div>'
                f'<div class="ty-tok mono">var(--t-{tok})</div></div>'
                f'<div class="ty-sample" style="font-size:{px}px;font-weight:{wt};'
                f'letter-spacing:{tr};line-height:{lh};'
                f'{"text-transform:uppercase" if name=="Micro" else ""}">'
                f'Verified pipeline, not self-reported</div>'
                f'<div class="ty-why muted">{why}</div></div>')
    return out


def scale_bars(items, unit="px"):
    return "".join(
        f'<div class="sc"><div class="sc-bar" style="width:{v}px"></div>'
        f'<div class="sc-lab mono">{n}</div><div class="sc-val mono">{v}{unit}</div></div>'
        for n, v in items)


AUDIT = [
    ("Emoji used as interface icons", "330 uses, 51 distinct",
     "🎙 📋 📧 🤖 🔔 🔌 🎯 🧭 🧩 🪟 🟢 🟣 ⚡ ⭐ 💰 📊",
     "This is the single loudest tell. Emoji render differently on every platform, "
     "cannot be recoloured, cannot be sized to the grid, and read as a chat window "
     "rather than a product. Nothing else on this list matters as much."),
    ("Corner radii", "21 distinct declarations",
     "2, 4, 5, 6, 7, 8, 9, 10, 12, 14, 16, 20px",
     "A radius set this wide is a sign that each component was decided on its own. "
     "The eye cannot name the shape language, so it reads as assembled rather than designed."),
    ("Type sizes", "22 distinct values",
     "9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 20, 22, 24, 28, 32, 36px",
     "Sixteen of these are in active use. Ten of them differ from a neighbour by 1px, "
     "which is a difference nobody can perceive but every layout has to absorb."),
    ("Colour literals", "93 distinct, 33 hex and 60 rgba",
     "#6366f1, #60a5fa, #2563eb, #1d4ed8, #78716c, #44403c, #1c1917, #f97316, #1a1a2e",
     "Every one of those is a framework default: indigo-500, blue-400, blue-600, blue-700, "
     "stone-500, stone-700, stone-900, orange-500, and the stock dark-theme navy. "
     "They sit next to a warm gold brand and fight it."),
    ("Padding", "76 distinct declarations",
     "no shared grid",
     "Spacing decided per component means nothing lines up across components. "
     "This is what people mean when they say a UI feels loose."),
    ("Transitions", "16 distinct, 13 of them transition: all",
     "transition: all 0.2s",
     "transition: all animates properties you did not intend, including layout, "
     "which is why hover states feel slightly wobbly. It is also the default anyone "
     "writes when they are not thinking about motion."),
    ("Gold drift", "product gold is not brand gold",
     "#A0752A and #C9973E in the app, #B8860B and #C8961E in the identity",
     "Two golds, neither of which matches the letterhead. The identity and the product "
     "look like two companies."),
]


def audit_table():
    out = ""
    for what, count, evidence, why in AUDIT:
        out += (f'<div class="au"><div class="au-h"><div class="au-what">{what}</div>'
                f'<div class="au-count">{count}</div></div>'
                f'<div class="au-ev mono">{evidence}</div>'
                f'<div class="au-why">{why}</div></div>')
    return out


RULES = [
    ("No emoji anywhere in the interface",
     "Not in buttons, not in empty states, not in alerts, not in menu items. If a thing "
     "needs an icon, it gets a drawn icon on a 20px grid with a 1.5px stroke, matching the "
     "weight of the ECG trace in the mark. If no such icon exists, the thing gets a word "
     "instead. A word is always better than a rocket."),
    ("Two radii, and one of them is reserved",
     "2px for anything you click or type into. 3px for anything that contains other things. "
     "999px exists for avatars and the 6px status dot, and for nothing else. There are no "
     "pills in Samora. "
     "A status is a small rectangle with a hairline, because a rectangle looks decided and a "
     "pill looks decorative."),
    ("Borders do the work that shadows usually do",
     "One hairline, one colour, one pixel. Two elevation levels exist and both are almost "
     "invisible: they are for things that genuinely float, which is menus and dialogs and "
     "nothing else. A card does not float. Stacked soft shadows are the visual signature of "
     "a component library, not of a product."),
    ("Never write transition: all",
     "Two durations. 120ms for anything that responds to the pointer, 200ms for anything that "
     "enters or leaves. One curve, cubic-bezier(0.2, 0, 0, 1), which starts fast and settles. "
     "Name the property you are animating. If you cannot name it, do not animate it."),
    ("No colour that is not a token",
     "If a hex code appears anywhere outside the token file, it is a bug. This is the rule "
     "that keeps a framework default from creeping back in, because a framework default has "
     "no token to live in. There is exactly one white in the system, "
     "<code>--c-print-paper</code>, and it only applies on paper."),
    ("The gradient belongs to the logo and to paper",
     "The gold ramp is for the mark, the letterhead and print. In the product, gold is one "
     "flat value. A gradient button is the most recognisable machine-made detail there is."),
    ("Three weights, and caps only below 12px",
     "400, 500, 600. Nothing else is loaded, so nothing else can be used. Uppercase with "
     "letterspacing is permitted at 11px for labels and at nothing larger. Uppercase headings "
     "look like a template."),
    ("Numbers are tabular, right aligned, and never coloured alone",
     "Money and scores line up in columns because the figures are the same width. Colour is "
     "never the only carrier of meaning: a status has a label as well as a colour, so it "
     "survives being printed, screenshotted, or read by someone colourblind."),
    ("Density is a decision, not an accident",
     "Controls are 32px tall. Table rows are 36px. Running text stops at 68 characters. "
     "These are fixed so that two screens built by two people on two days still look like "
     "one product."),
    ("Empty states and errors are sentences",
     "Write what happened and what to do next. No shrugging, no exclamation marks, no "
     "apologies with emoji. The house rule on em dashes applies here as everywhere: "
     "Samora does not use them."),
]


def rules_html():
    return "".join(
        f'<div class="rule-item"><div class="rule-n mono">{i+1:02d}</div>'
        f'<div><div class="rule-t">{t}</div><div class="rule-b">{b}</div></div></div>'
        for i, (t, b) in enumerate(RULES))


VOICE_DO = [
    "Three deals need multithreading before Friday.",
    "Illinois Bell Holdings has had one stakeholder for 31 days.",
    "Pipeline verified against 412 emails and 18 meetings.",
    "We could not reach Gmail. Showing intelligence from 9:04 this morning.",
]
VOICE_DONT = [
    "🚀 Your pipeline is looking great!",
    "Oops! Something went wrong.",
    "AI-powered insights, supercharged for your revenue team.",
    "No data available.",
]

MARK_RULES = [
    ("Clear space", "On every side, keep a margin equal to the ring's band width. "
     "Nothing crosses it, including page edges."),
    ("Minimum size", "Badge on beige: 48px. Badge reversed on the dark ground: 32px. "
     "Full stacked lockup: 480px wide. Below those, the trace closes up."),
    ("Ground", "Beige for warm contexts, the deep brown reversal for anything small or "
     "anything dark. Flat gold on white is acceptable for a single-colour print."),
    ("Never", "Do not recolour the trace separately from the ring, do not remove the ring, "
     "do not stretch, do not rotate, do not add a drop shadow, and do not place the "
     "stacked lockup in a square avatar slot."),
]


def build():
    lock_svg = M.svg("lockup", None)
    horiz_svg = M.svg("horizontal", None, 0.10)
    badge_svg = M.svg("badge", None, 0.05)
    badge_rev = M.svg("badge", "#2B1B14", 0.05)

    css = TOKENS + """
/* ---- book chrome ---- */
body{background:var(--c-canvas);}
.wrap{display:grid;grid-template-columns:214px 1fr;gap:0;max-width:1360px;margin:0 auto;}
nav{position:sticky;top:0;align-self:start;height:100vh;overflow:auto;padding:var(--s-6) var(--s-4);
    border-right:var(--line-w) solid var(--c-line);}
nav .brandline{font-size:var(--t-3xs);font-weight:var(--w-semibold);letter-spacing:.16em;text-transform:uppercase;
    color:var(--c-accent-text);margin-bottom:var(--s-5);}
nav a{display:block;padding:5px 0;font-size:var(--t-xs);color:var(--c-text-2);text-decoration:none;
    border-bottom:var(--line-w) solid transparent;transition:color var(--dur-fast) var(--ease);}
nav a:hover{color:var(--c-accent-text);}
main{padding:var(--s-7) var(--s-7) 120px;min-width:0;}
section{padding:var(--s-7) 0;border-top:var(--line-w) solid var(--c-line);}
section:first-of-type{border-top:0;padding-top:0;}
.eyebrow{font-size:var(--t-3xs);font-weight:var(--w-semibold);letter-spacing:.14em;text-transform:uppercase;
    color:var(--c-text-3);margin-bottom:var(--s-2);}
.lede{font-size:var(--t-md);line-height:1.5;color:var(--c-text-2);max-width:64ch;margin:var(--s-3) 0 var(--s-5);}
h2{margin-bottom:var(--s-2);}
h3{margin:var(--s-6) 0 var(--s-3);}
.mono{font-variant-numeric:tabular-nums;font-feature-settings:"tnum";}
.grid2{display:grid;grid-template-columns:1fr 1fr;gap:var(--s-5);}
.grid3{display:grid;grid-template-columns:repeat(3,1fr);gap:var(--s-4);}
.tbl-tight td,.tbl-tight th{font-size:var(--t-2xs);}
.dot-sq{display:inline-block;width:11px;height:11px;border:var(--line-w) solid var(--c-line-strong);
    border-radius:var(--r-sm);vertical-align:-1px;margin-right:7px;}

/* cover */
.cover{padding:var(--s-8) 0 var(--s-7);}
.cover svg{width:290px;height:auto;display:block;}
.cover h1{font-size:var(--t-3xl);margin:var(--s-6) 0 0;letter-spacing:var(--track-display);}
.cover .sub{font-size:var(--t-lg);color:var(--c-text-2);margin-top:var(--s-2);}
.cover .meta{margin-top:var(--s-5);font-size:var(--t-2xs);color:var(--c-text-3);
    letter-spacing:.10em;text-transform:uppercase;}

/* swatches */
.sw-grid{display:grid;grid-template-columns:repeat(6,1fr);gap:var(--s-3);}
.sw-chip{height:60px;border:var(--line-w) solid var(--c-line);border-radius:var(--r-sm);}
.sw-name{font-size:var(--t-2xs);font-weight:var(--w-medium);margin-top:6px;}
.sw-hex{font-size:var(--t-3xs);color:var(--c-text-3);font-variant-numeric:tabular-nums;}
.sw-note{font-size:var(--t-3xs);color:var(--c-text-3);}

/* hue proof */
.hue{display:flex;gap:var(--s-4);align-items:stretch;}
.hue-card{flex:1;border:var(--line-w) solid var(--c-line);border-radius:var(--r-md);overflow:hidden;}
.hue-card .blk{height:96px;}
.hue-card .bd{padding:var(--s-3);font-size:var(--t-2xs);}

/* type */
.ty-row{display:grid;grid-template-columns:170px 1fr 240px;gap:var(--s-4);align-items:baseline;
    padding:var(--s-4) 0;border-bottom:var(--line-w) solid var(--c-line);}
.ty-name{font-size:var(--t-xs);font-weight:var(--w-semibold);}
.ty-spec,.ty-tok{font-size:var(--t-3xs);color:var(--c-text-3);}
.ty-sample{color:var(--c-text);}
.ty-why{font-size:var(--t-3xs);line-height:1.45;}

/* scales */
.sc{display:grid;grid-template-columns:1fr 90px 64px;gap:var(--s-3);align-items:center;
    padding:5px 0;}
.sc-bar{height:12px;background:var(--c-accent);border-radius:var(--r-sm);opacity:.85;}
.sc-lab,.sc-val{font-size:var(--t-3xs);color:var(--c-text-3);}
.sc-val{text-align:right;}

/* audit */
.au{border-left:2px solid var(--c-risk);padding:var(--s-3) 0 var(--s-4) var(--s-4);margin-bottom:var(--s-4);}
.au-h{display:flex;justify-content:space-between;align-items:baseline;gap:var(--s-4);}
.au-what{font-size:var(--t-md);font-weight:var(--w-semibold);}
.au-count{font-size:var(--t-2xs);color:var(--c-risk);font-weight:var(--w-semibold);white-space:nowrap;}
.au-ev{font-size:var(--t-2xs);color:var(--c-text-3);margin:4px 0 8px;word-break:break-word;}
.au-why{font-size:var(--t-xs);color:var(--c-text-2);line-height:1.5;max-width:70ch;}

/* rules */
.rule-item{display:grid;grid-template-columns:44px 1fr;gap:var(--s-3);padding:var(--s-4) 0;
    border-bottom:var(--line-w) solid var(--c-line);}
.rule-n{font-size:var(--t-2xs);color:var(--c-accent-text);font-weight:var(--w-semibold);padding-top:2px;}
.rule-t{font-size:var(--t-md);font-weight:var(--w-semibold);margin-bottom:4px;}
.rule-b{font-size:var(--t-xs);color:var(--c-text-2);line-height:1.55;max-width:72ch;}

/* voice */
.vc{border:var(--line-w) solid var(--c-line);border-radius:var(--r-md);padding:var(--s-4);}
.vc h4{margin-bottom:var(--s-3);}
.vc p{font-size:var(--t-xs);margin:0 0 var(--s-2);padding-left:var(--s-4);position:relative;}
.vc p::before{position:absolute;left:0;font-weight:var(--w-semibold);}
.vc.do p::before{content:'+';color:var(--c-verified);}
.vc.dont p::before{content:'\\2013';color:var(--c-risk);}

/* demo panel */
.demo{border:var(--line-w) solid var(--c-line);border-radius:var(--r-md);overflow:hidden;background:var(--c-canvas);color:var(--c-text);}
.demo-bar{display:flex;justify-content:space-between;align-items:center;padding:var(--s-2) var(--s-3);
    background:var(--c-surface-2);border-bottom:var(--line-w) solid var(--c-line);
    font-size:var(--t-3xs);letter-spacing:.10em;text-transform:uppercase;color:var(--c-text-3);}
.demo-body{padding:var(--s-5);background:var(--c-canvas);}
.row{display:flex;gap:var(--s-3);align-items:center;flex-wrap:wrap;}
.stack{display:flex;flex-direction:column;gap:var(--s-3);}
.kpi{border:var(--line-w) solid var(--c-line);border-radius:var(--r-md);padding:var(--s-4);background:var(--c-surface);}
.kpi .k{font-size:var(--t-3xs);letter-spacing:.10em;text-transform:uppercase;color:var(--c-text-3);}
.kpi .v{color:var(--c-text);font-size:var(--t-2xl);font-weight:var(--w-semibold);line-height:1.1;margin-top:6px;letter-spacing:-0.01em;}
.kpi .d{font-size:var(--t-2xs);color:var(--c-text-2);margin-top:4px;}
.mark-box{border:var(--line-w) solid var(--c-line);border-radius:var(--r-md);padding:var(--s-6);
    display:flex;align-items:center;justify-content:center;}
.mark-box svg{width:100%;height:auto;max-width:260px;}
.mark-box.rev{background:var(--brand-ink);}
.mark-box.beige{background:var(--brand-beige);}
.sizes{display:flex;align-items:flex-end;gap:var(--s-5);flex-wrap:wrap;}
.sizes figure{margin:0;text-align:center;}
.sizes svg{display:block;width:100%;height:auto;}
.sizes figcaption{font-size:var(--t-3xs);color:var(--c-text-3);margin-top:6px;}
code{font-size:var(--t-2xs);background:var(--c-surface-2);padding:1px 5px;border-radius:var(--r-sm);
     border:var(--line-w) solid var(--c-line);}
pre{background:var(--c-surface-2);border:var(--line-w) solid var(--c-line);border-radius:var(--r-md);
    padding:var(--s-4);overflow:auto;font-size:var(--t-2xs);line-height:1.55;}

@media (max-width:1000px){.wrap{grid-template-columns:1fr}nav{display:none}
  .grid2,.grid3,.sw-grid{grid-template-columns:1fr}.ty-row{grid-template-columns:1fr}}

/* ---- print ---- */
@page{size:A4;margin:16mm 14mm 18mm;}
@media print{
  html,body{background:#FFFFFF !important;}
  .wrap{display:block;max-width:none;}
  nav{display:none;}
  main{padding:0;}
  section{border-top:0;padding:0 0 10mm;break-before:page;}
  section:first-of-type{break-before:auto;}
  header.cover{break-after:page;padding:0;}
  h2,h3{break-after:avoid;}
  .ty-row,.rule-item,.au,.sw,.kpi,.hue-card,tr{break-inside:avoid;}
  .demo{break-inside:avoid;}
  table{font-size:10px;}
  .table th{letter-spacing:.04em;padding-right:10px;}
  .table td,.table th{padding-right:8px;}
  .sw-grid{grid-template-columns:repeat(4,1fr) !important;}
  .grid2{grid-template-columns:1fr 1fr !important;}
  .grid3{grid-template-columns:repeat(3,1fr) !important;}
  .sw-chip{height:44px;}
  .ty-row{grid-template-columns:130px 1fr 170px !important;}
  .ty-sample{overflow:hidden;}
  a{text-decoration:none;color:inherit;}
  pre{white-space:pre-wrap;}
}
"""

    nav_items = [("premise", "The premise"), ("mark", "The mark"), ("colour", "Colour"),
                 ("type", "Typography"), ("space", "Space, radius, line"), ("motion", "Motion"),
                 ("components", "Components"), ("diagnosis", "Diagnosis"),
                 ("rules", "The ten rules"), ("voice", "Voice"), ("adopt", "How to adopt")]
    nav = "".join(f'<a href="#{i}">{t}</a>' for i, t in nav_items)

    sizes = "".join(
        f'<figure><div style="width:{px}px">{M.svg("badge", None, 0.05)}</div>'
        f'<figcaption>{px}px</figcaption></figure>' for px in (128, 96, 64, 48, 32))

    mark_rules_html = "".join(
        f'<div><div class="ty-name">{t}</div><div class="rule-b">{b}</div></div>'
        for t, b in MARK_RULES)

    gold_L, gold_C, gold_H = P.lch(P.GOLD)
    beige_L, beige_C, beige_H = P.lch(P.BEIGE)

    html = f"""<!DOCTYPE html>
<html lang="en" data-theme="light"><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Samora Brand Book</title>
<style>{FACES}</style>
<style>{css}</style>
</head><body><div class="wrap">
<nav><div class="brandline">Samora<br>Brand Book</div>{nav}</nav>
<main>

<header class="cover">
  {lock_svg}
  <h1>Brand Book</h1>
  <div class="sub">The identity, the interface, and the rules that keep the second one
  from looking machine made.</div>
  <div class="meta">RevEngine Samora Private Limited &nbsp;&middot;&nbsp; Version 1.0 &nbsp;&middot;&nbsp; August 2026</div>
</header>

<section id="premise">
  <div class="eyebrow">01</div>
  <h2>The premise</h2>
  <p class="lede">A brand book is usually a colour chart with opinions attached. This one starts
  from a measurement, because the measurement turned out to be the whole system.</p>

  <p>The gold in the mark and the beige it sits on are not two colours that happen to
  go together. Converted to Oklch, they share a hue to within a fifth of a degree: the
  gold sits at <strong>{math.degrees(gold_H):.2f} degrees</strong> and the beige at
  <strong>{math.degrees(beige_H):.2f} degrees</strong>. They are the same colour at different
  lightness and chroma. Metal and paper, one hue.</p>

  <div class="hue">
    <div class="hue-card"><div class="blk" style="background:{P.GOLD}"></div>
      <div class="bd"><strong>Gold {P.GOLD}</strong><br>
      L {gold_L:.3f} &nbsp; C {gold_C:.4f} &nbsp; H {math.degrees(gold_H):.1f}&deg;</div></div>
    <div class="hue-card"><div class="blk" style="background:{P.BEIGE}"></div>
      <div class="bd"><strong>Beige {P.BEIGE}</strong><br>
      L {beige_L:.3f} &nbsp; C {beige_C:.4f} &nbsp; H {math.degrees(beige_H):.1f}&deg;</div></div>
  </div>

  <p style="margin-top:var(--s-5)">So every neutral in the product is built on that one hue at
  twelve lightness steps. Nothing is grey. Nothing is imported. A card, a table rule, a
  disabled label and the logo are all relatives, which is why the interface can look like
  the identity without ever repeating it.</p>

  <p>Two caveats, stated rather than buried. The lightness steps are not evenly spaced:
  they are deliberately compressed at both ends so the palest steps stay paper and the
  darkest stay ink. And at the top of the ramp, where chroma is under 0.015, eight-bit
  rounding moves the hue by a few degrees. Neither is visible. Both are in the source.</p>

  <p>Everything downstream of that is restraint: one typeface, two corner radii, one border
  width, two durations. The character comes from the mark and from the warmth of the ramp.
  The interface itself gets out of the way.</p>
</section>

<section id="mark">
  <div class="eyebrow">02</div>
  <h2>The mark</h2>
  <p class="lede">One continuous ECG trace running a single cardiac cycle. P wave in from the
  left, the S of Samora sitting where the PR segment runs, QRS complex out to the right.
  Both tails run into the ring.</p>

  <div class="grid3">
    <div class="mark-box beige">{badge_svg}</div>
    <div class="mark-box rev">{badge_rev}</div>
    <div class="mark-box beige">{horiz_svg}</div>
  </div>

  <h3>Behaviour at size</h3>
  <div class="sizes">{sizes}</div>

  <h3>Rules</h3>
  <div class="stack">{mark_rules_html}</div>

  <h3>Construction, for reference</h3>
  <table class="table tbl-tight"><tbody>
    <tr><td>S box width</td><td class="mono">0.60 of its height</td></tr>
    <tr><td>Trace stroke</td><td class="mono">0.154 of the S box height</td></tr>
    <tr><td>Ring band</td><td class="mono">0.150 of the outer radius</td></tr>
    <tr><td>P wave</td><td class="mono">depth 0.085, width 0.560, raised cosine</td></tr>
    <tr><td>Interior clearance</td><td class="mono">0.84 of the inner radius</td></tr>
    <tr><td>Tail burial</td><td class="mono">0.60 into the band, so the cap leaves no crescent</td></tr>
    <tr><td>Joins</td><td class="mono">miter, limit 6</td></tr>
  </tbody></table>
</section>

<section id="colour">
  <div class="eyebrow">03</div>
  <h2>Colour</h2>
  <p class="lede">Twelve neutrals on one hue, four status colours rotated off the gold, and
  nothing else. There is no blue in this brand unless it is carrying information, and even
  then it is desaturated to the point of being a slate.</p>

  <h3>The sand ramp</h3>
  <div class="sw-grid">{sand_row()}</div>
  <p style="margin-top:var(--s-4)"><code>sand 10</code> is the brand beige exactly. That is not a
  coincidence, it is the anchor the ramp was solved around.</p>

  <h3>Roles</h3>
  <div class="grid2">
    <div>{role_table(P.LIGHT, "Light")}</div>
    <div>{role_table(P.DARK, "Dark")}</div>
  </div>
  <p style="margin-top:var(--s-4)">Always use the role, never the ramp step. The role is what
  makes light and dark mode a single decision instead of two stylesheets.</p>

  <h3>Status</h3>
  <div class="row" style="margin-bottom:var(--s-4)">
    <span class="tag tag--verified">Verified</span>
    <span class="tag tag--partial">Partial</span>
    <span class="tag tag--risk">At risk</span>
    <span class="tag tag--info">Info</span>
    <span class="tag tag--neutral">Unverified</span>
  </div>
  <p>Olive for verified, the brand gold for partial, terracotta for risk. Each is a rotation
  off the gold's own hue rather than a colour borrowed from somewhere else, which is why they
  sit on the beige without arguing with it.</p>

  <h3>Contrast, measured</h3>
  <p>Every pairing below is computed, not assumed, and the build fails if any row fails.
  Two of these are worth pointing at. The filled gold button is measured against
  <code>--c-accent-solid</code> rather than <code>--c-accent</code>, because the display
  gold only manages 3.1:1 behind text and cannot be a button. And each status colour is
  measured against its own ten percent wash rather than the bare card, because the wash is
  what the text actually sits on. Measuring against the card overstates every one of them.</p>
  {contrast_table()}
</section>

<section id="type">
  <div class="eyebrow">04</div>
  <h2>Typography</h2>
  <p class="lede">One family: <strong>Archivo</strong>. It carries the wordmark, the product and
  print. Three weights are loaded, so three weights are all that can be used.</p>

  <p>Archivo is a grotesque drawn for high performance at small sizes, with unambiguous
  figures and a real tabular set. That matters more here than in most products, because
  Samora is mostly numbers in columns. It is also not one of the faces that ships as a
  framework default, which is half the reason an interface reads as generic.</p>

  <h3>The scale</h3>
  {type_specimen()}

  <h3>Rules</h3>
  <div class="stack" style="margin-top:var(--s-4)">
    <div><div class="ty-name">Tabular figures are always on</div>
      <div class="rule-b">Set at the body level, not per component. Money and scores must line up
      in a column without anybody remembering to ask.</div></div>
    <div><div class="ty-name">Uppercase only at 11px</div>
      <div class="rule-b">With 0.10em tracking, for labels and table headers. An uppercase heading
      is the fastest way to make a page look like a template.</div></div>
    <div><div class="ty-name">Running text stops at 68 characters</div>
      <div class="rule-b">Set on the paragraph, not on the container, so it holds regardless of
      what the layout does.</div></div>
    <div><div class="ty-name">Never more than three weights on one screen</div>
      <div class="rule-b">And 600 is a heading weight. If a body paragraph needs 600 to be noticed,
      the layout is wrong, not the type.</div></div>
  </div>
</section>

<section id="space">
  <div class="eyebrow">05</div>
  <h2>Space, radius, line</h2>
  <p class="lede">A 4px grid, eight steps, no exceptions. Two corner radii. One border width.
  This is the part of the system that most changes how deliberate a product feels.</p>

  <div class="grid2">
    <div>
      <h3 style="margin-top:0">Spacing</h3>
      {scale_bars([('--s-1',4),('--s-2',8),('--s-3',12),('--s-4',16),('--s-5',24),('--s-6',32),('--s-7',48),('--s-8',64)])}
    </div>
    <div>
      <h3 style="margin-top:0">Radius</h3>
      <div class="row" style="margin-bottom:var(--s-4)">
        <div style="width:80px;height:56px;background:var(--c-surface-3);border:var(--line-w) solid var(--c-line-strong);border-radius:2px"></div>
        <div style="width:80px;height:56px;background:var(--c-surface-3);border:var(--line-w) solid var(--c-line-strong);border-radius:3px"></div>
        <div style="width:56px;height:56px;background:var(--c-surface-3);border:var(--line-w) solid var(--c-line-strong);border-radius:999px"></div>
      </div>
      <table class="table tbl-tight"><tbody>
        <tr><td><code>--r-sm</code> 2px</td><td class="muted">buttons, inputs, chips, tags</td></tr>
        <tr><td><code>--r-md</code> 3px</td><td class="muted">cards, panels, menus, dialogs</td></tr>
        <tr><td><code>--r-round</code></td><td class="muted">avatars and the 6px status dot. Nothing else.</td></tr>
      </tbody></table>
      <h3>Density</h3>
      <table class="table tbl-tight"><tbody>
        <tr><td>Control height</td><td class="mono">32px</td></tr>
        <tr><td>Small control</td><td class="mono">26px</td></tr>
        <tr><td>Table row</td><td class="mono">36px</td></tr>
        <tr><td>Border width</td><td class="mono">1px, one colour</td></tr>
        <tr><td>Text measure</td><td class="mono">68ch</td></tr>
      </tbody></table>
    </div>
  </div>

  <h3>Elevation</h3>
  <p>Two levels, both nearly invisible, both tinted with the ink rather than pure black.
  Shadows are for things that genuinely float. A card does not float.</p>
  <div class="row">
    <div class="card" style="width:200px">Flat. The default.</div>
    <div class="card card--raised" style="width:200px">Level 1. Menus.</div>
    <div class="card" style="width:200px;box-shadow:var(--shadow-2)">Level 2. Dialogs.</div>
  </div>
</section>

<section id="motion">
  <div class="eyebrow">06</div>
  <h2>Motion</h2>
  <p class="lede">Two durations, one curve, and a named property every time.</p>
  <table class="table"><thead><tr><th>Token</th><th>Value</th><th>Use</th></tr></thead><tbody>
    <tr><td><code>--dur-fast</code></td><td class="mono">120ms</td><td class="muted">hover, focus, colour change</td></tr>
    <tr><td><code>--dur-slow</code></td><td class="mono">200ms</td><td class="muted">enter, exit, size change</td></tr>
    <tr><td><code>--ease</code></td><td class="mono">cubic-bezier(0.2, 0, 0, 1)</td><td class="muted">everything</td></tr>
  </tbody></table>
  <pre>/* wrong */
transition: all 0.2s;

/* right */
transition: background-color var(--dur-fast) var(--ease),
            border-color var(--dur-fast) var(--ease);</pre>
  <p>The fast duration belongs to hover, focus and colour. The slow one belongs to
  things that enter and leave, which in this system is exactly one component:
  <code>.pop</code>, used for menus and dialogs. If a third duration seems necessary,
  the interaction is wrong, not the scale.</p>
  <p>Everything respects <code>prefers-reduced-motion</code>. That is handled once in the token
  file, so no component has to think about it.</p>
</section>

<section id="components">
  <div class="eyebrow">07</div>
  <h2>Components</h2>
  <p class="lede">Live, not pictures. Everything below is rendered by the same token file you
  will paste into the product, so what you see here is what ships.</p>

  <div class="demo">
    <div class="demo-bar"><span>Pipeline health</span><span>Light</span></div>
    <div class="demo-body">
      <div class="grid3" style="margin-bottom:var(--s-5)">
        <div class="kpi"><div class="k">Verified pipeline</div><div class="v">1,735,500</div>
          <div class="d">62 percent of total, up from 54</div></div>
        <div class="kpi"><div class="k">Deals at risk</div><div class="v">7</div>
          <div class="d">Single threaded for over 21 days</div></div>
        <div class="kpi"><div class="k">Coverage</div><div class="v">2.4&times;</div>
          <div class="d">Against a 4,200,000 target</div>
          <div class="meter" style="margin-top:10px"><i style="width:60%"></i></div></div>
      </div>

      <table class="table">
        <thead><tr><th>Account</th><th>Tier</th><th class="num">Health</th>
          <th class="num">Stakeholders</th><th class="num">Close</th><th class="num">Value</th></tr></thead>
        <tbody>
          <tr><td>Acme Manufacturing</td><td><span class="tag tag--verified">Verified</span></td>
            <td class="num">82</td><td class="num">4</td><td class="num">12 Sep</td><td class="num">1,180,000</td></tr>
          <tr><td>Northgate Logistics</td><td><span class="tag tag--partial">Partial</span></td>
            <td class="num">61</td><td class="num">2</td><td class="num">30 Sep</td><td class="num">465,500</td></tr>
          <tr><td>Illinois Bell Holdings</td><td><span class="tag tag--risk">At risk</span></td>
            <td class="num">38</td><td class="num">1</td><td class="num">10 Oct</td><td class="num">90,000</td></tr>
          <tr><td>Fairweather Group</td><td><span class="tag tag--neutral">Unverified</span></td>
            <td class="num">&ndash;</td><td class="num">0</td><td class="num">&ndash;</td><td class="num">240,000</td></tr>
        </tbody>
      </table>

      <hr class="rule">
      <div class="row">
        <button class="btn btn--primary">Verify pipeline</button>
        <button class="btn">Export</button>
        <button class="btn btn--quiet">Cancel</button>
        <button class="btn" disabled>Unavailable</button>
        <input class="input" style="width:200px" placeholder="Search accounts">
      </div>
    </div>
  </div>

  <div class="demo" style="margin-top:var(--s-5)" data-theme="dark">
    <div class="demo-bar"><span>The same panel</span><span>Dark</span></div>
    <div class="demo-body">
      <div class="grid3" style="margin-bottom:var(--s-5)">
        <div class="kpi"><div class="k">Verified pipeline</div><div class="v">1,735,500</div>
          <div class="d">62 percent of total, up from 54</div></div>
        <div class="kpi"><div class="k">Deals at risk</div><div class="v">7</div>
          <div class="d">Single threaded for over 21 days</div></div>
        <div class="kpi"><div class="k">Coverage</div><div class="v">2.4&times;</div>
          <div class="d">Against a 4,200,000 target</div>
          <div class="meter" style="margin-top:10px"><i style="width:60%"></i></div></div>
      </div>
      <div class="row">
        <span class="tag tag--verified">Verified</span>
        <span class="tag tag--partial">Partial</span>
        <span class="tag tag--risk">At risk</span>
        <span class="tag tag--neutral">Unverified</span>
        <button class="btn btn--primary">Verify pipeline</button>
        <button class="btn">Export</button>
      </div>
    </div>
  </div>
</section>

<section id="diagnosis">
  <div class="eyebrow">08</div>
  <h2>Diagnosis</h2>
  <p class="lede">This section exists because the complaint was specific: the product looks
  machine made. That is a fair reading, and it is measurable. Here is what the current
  stylesheet actually contains.</p>
  {audit_table()}
  <p style="margin-top:var(--s-5)">None of this is a failure of taste. It is what happens when
  every component is decided at the moment it is written. A system removes that moment.</p>
</section>

<section id="rules">
  <div class="eyebrow">09</div>
  <h2>The ten rules</h2>
  <p class="lede">If you only read one section, read this one. These are the decisions that
  separate a product that looks authored from one that looks assembled.</p>
  {rules_html()}
</section>

<section id="voice">
  <div class="eyebrow">10</div>
  <h2>Voice</h2>
  <p class="lede">Samora sells certainty about numbers. The writing should sound like someone
  who has already checked.</p>
  <p>Specific over enthusiastic. A count, a date, a name. Never a promise, never an
  exclamation mark, never an apology dressed up as a mascot. When something fails, say what
  failed and what the user is looking at instead.</p>
  <div class="grid2" style="margin-top:var(--s-5)">
    <div class="vc do"><h4>This</h4>{"".join(f"<p>{s}</p>" for s in VOICE_DO)}</div>
    <div class="vc dont"><h4>Not this</h4>{"".join(f"<p>{s}</p>" for s in VOICE_DONT)}</div>
  </div>
  <h3>House rules</h3>
  <div class="stack">
    <div><div class="ty-name">No em dashes, ever</div><div class="rule-b">In any Samora content,
      anywhere. Use a comma, a full stop, or restructure the sentence.</div></div>
    <div><div class="ty-name">Sentence case for everything except 11px labels</div>
      <div class="rule-b">Button text, menu items, headings. Title Case Everywhere reads as a
      template.</div></div>
    <div><div class="ty-name">RevEngine is one word, camel case</div><div class="rule-b">The legal
      entity is RevEngine Samora Private Limited. Never all caps, never two words.</div></div>
    <div><div class="ty-name">The product is Samora, the platform is SamoraTrack</div>
      <div class="rule-b">Use Samora when speaking as a company, SamoraTrack when naming the
      software.</div></div>
  </div>
</section>

<section id="adopt">
  <div class="eyebrow">11</div>
  <h2>How to adopt this</h2>
  <p class="lede">The token file does most of the work. The rest is deletion.</p>
  <ol style="font-size:var(--t-sm);line-height:1.7;max-width:70ch;padding-left:var(--s-5)">
    <li>Load Archivo at 400, 500 and 600. Nothing else.</li>
    <li>Paste <code>samora-tokens.css</code> in place of the current <code>:root</code> block and
      the light and dark overrides.</li>
    <li>Run the mapping table below and replace every old variable.</li>
    <li>Delete every emoji in the markup. Where one carried meaning, use a word.</li>
    <li>Search the file for <code>#</code> and <code>rgba(</code>. Every remaining hit is a bug.</li>
    <li>Search for <code>transition:all</code> and name the properties.</li>
    <li>Search for <code>border-radius</code> and reduce every value to
      <code>var(--r-sm)</code> or <code>var(--r-md)</code>.</li>
  </ol>

  <h3>Variable mapping</h3>
  <table class="table"><thead><tr><th>Today</th><th>Replace with</th><th>Note</th></tr></thead><tbody>
    <tr><td class="mono">--bg</td><td class="mono">--c-canvas</td><td class="muted">page ground</td></tr>
    <tr><td class="mono">--surface</td><td class="mono">--c-surface</td><td class="muted">cards</td></tr>
    <tr><td class="mono">--surface2</td><td class="mono">--c-surface-2</td><td class="muted">hover, inset</td></tr>
    <tr><td class="mono">--surface3</td><td class="mono">--c-surface-3</td><td class="muted">wells, tracks</td></tr>
    <tr><td class="mono">--border</td><td class="mono">--c-line</td><td class="muted">one width, one colour</td></tr>
    <tr><td class="mono">--border2</td><td class="mono">--c-line-strong</td><td class="muted">controls only</td></tr>
    <tr><td class="mono">--text</td><td class="mono">--c-text</td><td class="muted"></td></tr>
    <tr><td class="mono">--text2</td><td class="mono">--c-text-2</td><td class="muted"></td></tr>
    <tr><td class="mono">--text3</td><td class="mono">--c-text-3</td><td class="muted"></td></tr>
    <tr><td class="mono">--gold, --gold-lt, --gold-pl</td><td class="mono">--c-accent</td>
      <td class="muted">three golds collapse to one</td></tr>
    <tr><td class="mono">--green, --green-lt</td><td class="mono">--c-verified, --c-verified-wash</td><td class="muted"></td></tr>
    <tr><td class="mono">--amber, --amber-lt, --miss</td><td class="mono">--c-partial, --c-partial-wash</td><td class="muted"></td></tr>
    <tr><td class="mono">--coral, --coral-lt</td><td class="mono">--c-risk, --c-risk-wash</td><td class="muted"></td></tr>
    <tr><td class="mono">--radius-sm, --radius, --radius-lg, --radius-xl</td>
      <td class="mono">--r-sm, --r-md</td><td class="muted">four collapse to two</td></tr>
    <tr><td class="mono">--serif, --sans</td><td class="mono">--font</td><td class="muted">one family</td></tr>
    <tr><td class="mono">--ease</td><td class="mono">--ease</td><td class="muted">value changes, name stays</td></tr>
  </tbody></table>

  <h3>Icons</h3>
  <p>Emoji come out. In their place, use a single stroke set at 1.5px on a 20px grid so the
  icons carry the same line weight as the ECG trace. Phosphor Icons at regular weight is a
  good fit and is MIT licensed. Avoid Lucide: it is the default that ships with the component
  library everyone recognises, which puts you back where you started.</p>

  <h3>Files</h3>
  <table class="table"><thead><tr><th>File</th><th>What it is</th></tr></thead><tbody>
    <tr><td class="mono">samora-tokens.css</td><td class="muted">the drop-in token and component layer</td></tr>
    <tr><td class="mono">palette.py</td><td class="muted">generates the colour, with the contrast audit</td></tr>
    <tr><td class="mono">marks/</td><td class="muted">logo lockups, SVG and PNG, on the single family</td></tr>
    <tr><td class="mono">samora-brand-book.html</td><td class="muted">this document</td></tr>
    <tr><td class="mono">samora-brand-book.pdf</td><td class="muted">the sendable version</td></tr>
  </tbody></table>
</section>

</main></div></body></html>"""
    return html


if __name__ == "__main__":
    h = build()
    open(f"{HERE}/samora-brand-book.html", "w").write(h)
    print("wrote samora-brand-book.html", len(h), "bytes")
