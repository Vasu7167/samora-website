"""Brand applications rebuilt on the single family: A4 letterhead and LinkedIn assets."""
import sys, os, math
sys.path.insert(0, "/home/claude/logo")
os.chdir("/home/claude/logo")
import final as F
import marks as M
import palette as P
from typeset import typeset, metrics
from inkbox import measure

OUT = "/home/claude/brand/applications"
os.makedirs(OUT, exist_ok=True)

FAM = M.FAM
MM = 595.276 / 210.0
PW, PH = 595.276, 841.890
MARGIN = 22 * MM
BEIGE, GOLD = P.BEIGE, P.GOLD
DARK = P.LIGHT["text"]                 # #171005, the ramp's darkest step
COMPANY = "RevEngine Samora Private Limited"
ADDR = "#126, Sector 10 A, Chandigarh 160011"


def ink(t, w, s, tr, x0=0.0, b=0.0):
    return typeset(t, FAM, w, s, tr, 0.0, b, x0)


def grad(box):
    return M.gradient(box)


# ------------------------------------------------------------------ letterhead
def letterhead(ground=BEIGE, rule=True):
    lock_h = 20 * MM
    body, lb = M.horizontal()
    s = lock_h / lb[3]
    body_scaled = f'<g transform="scale({s:.6f})">{body}</g>'
    w, h = lb[2] * s, lb[3] * s
    top_y = 18 * MM

    out = [f'<rect width="{PW}" height="{PH}" fill="{ground}"/>',
           f'<g transform="translate({MARGIN:.2f},{top_y:.2f})">{body_scaled}</g>']
    if rule:
        out.append(f'<rect x="{MARGIN:.2f}" y="{top_y + h + 7*MM:.2f}" '
                   f'width="{PW - 2*MARGIN:.2f}" height="0.5" fill="{GOLD}" opacity="0.85"/>')
    fy = PH - 20 * MM
    if rule:
        out.append(f'<rect x="{MARGIN:.2f}" y="{fy - 7*MM:.2f}" width="{PW - 2*MARGIN:.2f}" '
                   f'height="0.5" fill="{GOLD}" opacity="0.85"/>')
    cd, _, (c0, *_a) = ink(COMPANY, 500, 8.0, 18)
    out.append(f'<g transform="translate({MARGIN - c0:.2f},{fy - 2.2*MM:.2f})">'
               f'<path d="{cd}" fill="{DARK}"/></g>')
    ad, _, (d0, _, d1, _) = ink(ADDR, 400, 7.6, 30)
    out.append(f'<g transform="translate({PW - MARGIN - (d1-d0) - d0:.2f},{fy - 2.2*MM:.2f})">'
               f'<path d="{ad}" fill="{DARK}" opacity="0.78"/></g>')
    return (f'<svg xmlns="http://www.w3.org/2000/svg" width="{PW:.2f}" height="{PH:.2f}" '
            f'viewBox="0 0 {PW:.2f} {PH:.2f}"><defs>{grad(lb)}</defs>{"".join(out)}</svg>')


# ------------------------------------------------------------------ linkedin
LW, LH = 1128.0, 191.0


def li_logo(px=400, ground=BEIGE, fill=0.82):
    r = F.R_OUT
    s = (px * fill) / (2 * r)
    body, box = M.badge()
    return (f'<svg xmlns="http://www.w3.org/2000/svg" width="{px}" height="{px}" '
            f'viewBox="0 0 {px} {px}"><defs>{grad((-r, -r, r, r))}</defs>'
            f'<rect width="{px}" height="{px}" fill="{ground}"/>'
            f'<g transform="translate({px/2},{px/2}) scale({s:.6f})">{body}</g></svg>')


def li_cover(ground=BEIGE):
    box = measure(F.d_of(F.PTS), F.SW, join="miter", miterlimit=F.MITER, cap="butt",
                  rough=(-400, -400, 800, 800), px=1600)
    sc = (LH * 0.72) / (box[3] - box[1])
    pts = [(x * sc, y * sc) for x, y in F.PTS]
    sw = F.SW * sc
    cy = (box[1] + box[3]) / 2.0 * sc
    fx = LW * 0.330
    pts = [(x + fx, y - cy + LH * 0.50) for x, y in pts]
    pts[0] = (-4.0, pts[0][1])
    pts[-1] = (LW + 4.0, pts[-1][1])

    tx, ww = LW * 0.555, LW * 0.330
    ws = M._solve("SAMORA", FAM, M.WT, M.TRACK, ww)
    m = metrics(FAM, M.WT)
    wc = m["cap"] / m["upm"] * ws
    ts = M._solve(M.TAG, FAM, 400, M.TAG_TRACK, ww)
    m4 = metrics(FAM, 400)
    tc = m4["cap"] / m4["upm"] * ts
    total = wc + wc * 0.62 + tc
    wby = (LH - total) / 2.0 + wc
    tby = wby + wc * 0.62 + tc
    _, _, (a0, *_a) = ink("SAMORA", M.WT, ws, M.TRACK)
    wd, _, _ = ink("SAMORA", M.WT, ws, M.TRACK, tx - a0, wby)
    _, _, (t0, *_b) = ink(M.TAG, 400, ts, M.TAG_TRACK)
    td, _, _ = ink(M.TAG, 400, ts, M.TAG_TRACK, tx - t0, tby)

    gt = (f'<linearGradient id="tg" gradientUnits="userSpaceOnUse" x1="0" y1="0" x2="{LW}" y2="0">'
          f'<stop offset="0%" stop-color="{P.GOLD}"/><stop offset="18%" stop-color="{P.GOLD_BRIGHT}"/>'
          f'<stop offset="38%" stop-color="{P.GOLD_WARM}"/><stop offset="46%" stop-color="{P.GOLD_WARM}"/>'
          f'<stop offset="53%" stop-color="{P.GOLD_WARM}" stop-opacity="0"/></linearGradient>')
    gw = (f'<linearGradient id="wg" gradientUnits="userSpaceOnUse" x1="{tx}" y1="0" '
          f'x2="{tx+ww}" y2="{LH}"><stop offset="0%" stop-color="{P.GOLD}"/>'
          f'<stop offset="45%" stop-color="{P.GOLD_BRIGHT}"/>'
          f'<stop offset="100%" stop-color="{P.GOLD_WARM}"/></linearGradient>')
    return (f'<svg xmlns="http://www.w3.org/2000/svg" width="{LW:.0f}" height="{LH:.0f}" '
            f'viewBox="0 0 {LW:.0f} {LH:.0f}"><defs>{gt}{gw}</defs>'
            f'<rect width="{LW:.0f}" height="{LH:.0f}" fill="{ground}"/>'
            f'<path d="{F.d_of(pts)}" fill="none" stroke="url(#tg)" stroke-width="{sw:.2f}" '
            f'stroke-linecap="butt" stroke-linejoin="miter" stroke-miterlimit="{F.MITER}"/>'
            f'<path d="{wd}" fill="url(#wg)"/><path d="{td}" fill="url(#wg)"/></svg>')


if __name__ == "__main__":
    import cairosvg
    jobs = [
        ("samora-letterhead-beige", letterhead(BEIGE), 1240, True),
        ("samora-letterhead-white", letterhead("#FFFFFF"), 1240, True),
        ("samora-li-logo-beige", li_logo(400, BEIGE), 400, False),
        ("samora-li-logo-dark", li_logo(400, P.INK), 400, False),
        ("samora-li-cover-beige", li_cover(BEIGE), 2256, False),
        ("samora-li-cover-dark", li_cover(P.INK), 2256, False),
    ]
    for name, s, w, pdf in jobs:
        open(f"{OUT}/{name}.svg", "w").write(s)
        cairosvg.svg2png(bytestring=s.encode(), write_to=f"{OUT}/{name}.png", output_width=w)
        if pdf:
            cairosvg.svg2pdf(bytestring=s.encode(), write_to=f"{OUT}/{name}.pdf")
    print("wrote", len(os.listdir(OUT)), "files")
