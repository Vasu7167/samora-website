"""Samora palette, generated in Oklab rather than picked by eye.

Everything derives from three fixed anchors taken off the locked logo:
    gold  #B8860B    beige #F0E8DA    ink   #2B1B14

The neutral ramp is a single hue held constant, with lightness stepped in Oklab
and deliberately compressed at both ends so the lightest steps stay paper and the
darkest stay ink. Light and dark mode are the same ramp read from opposite ends.
Nothing here is a framework default.
"""
import math, json

# ---------------------------------------------------------------- colour math
def _srgb_to_lin(c):
    c /= 255.0
    return c / 12.92 if c <= 0.04045 else ((c + 0.055) / 1.055) ** 2.4


def _lin_to_srgb(c):
    v = 12.92 * c if c <= 0.0031308 else 1.055 * (c ** (1 / 2.4)) - 0.055
    return max(0, min(255, round(v * 255)))


def hex_to_rgb(h):
    h = h.lstrip("#")
    return tuple(int(h[i:i + 2], 16) for i in (0, 2, 4))


def rgb_to_hex(r, g, b):
    return "#%02X%02X%02X" % (r, g, b)


def to_oklab(h):
    r, g, b = (_srgb_to_lin(v) for v in hex_to_rgb(h))
    l = 0.4122214708 * r + 0.5363325363 * g + 0.0514459929 * b
    m = 0.2119034982 * r + 0.6806995451 * g + 0.1073969566 * b
    s = 0.0883024619 * r + 0.2817188376 * g + 0.6299787005 * b
    l_, m_, s_ = l ** (1 / 3), m ** (1 / 3), s ** (1 / 3)
    return (0.2104542553 * l_ + 0.7936177850 * m_ - 0.0040720468 * s_,
            1.9779984951 * l_ - 2.4285922050 * m_ + 0.4505937099 * s_,
            0.0259040371 * l_ + 0.7827717662 * m_ - 0.8086757660 * s_)


def from_oklab(L, a, b):
    l_ = L + 0.3963377774 * a + 0.2158037573 * b
    m_ = L - 0.1055613458 * a - 0.0638541728 * b
    s_ = L - 0.0894841775 * a - 1.2914855480 * b
    l, m, s = l_ ** 3, m_ ** 3, s_ ** 3
    r = 4.0767416621 * l - 3.3077115913 * m + 0.2309699292 * s
    g = -1.2684380046 * l + 2.6097574011 * m - 0.3413193965 * s
    bb = -0.0041960863 * l - 0.7034186147 * m + 1.7076147010 * s
    return rgb_to_hex(_lin_to_srgb(r), _lin_to_srgb(g), _lin_to_srgb(bb))


def lch(h):
    L, a, b = to_oklab(h)
    return L, math.hypot(a, b), math.atan2(b, a)


def from_lch(L, C, H):
    return from_oklab(L, C * math.cos(H), C * math.sin(H))


# ---------------------------------------------------------------- contrast
def _lum(h):
    r, g, b = (_srgb_to_lin(v) for v in hex_to_rgb(h))
    return 0.2126 * r + 0.7152 * g + 0.0722 * b


def cr(a, b):
    la, lb = _lum(a), _lum(b)
    hi, lo = max(la, lb), min(la, lb)
    return (hi + 0.05) / (lo + 0.05)


def composite(fg, bg, alpha):
    """Flatten a translucent wash over a ground, so contrast is measured against
    what the eye actually sees rather than against the bare surface."""
    f, b = hex_to_rgb(fg), hex_to_rgb(bg)
    return rgb_to_hex(*[round(f[i] * alpha + b[i] * (1 - alpha)) for i in range(3)])


def solve_L(C, H, against, minimum, light_ground=True, margin=1.03):
    """Return the lightest colour at this hue and chroma that still clears
    `minimum` against `against` on a light ground, or the darkest that does on a
    dark ground. Bisection on a monotone predicate, so it cannot be fudged.
    `margin` keeps a little headroom above the threshold."""
    need = minimum * margin
    lo, hi = 0.02, 0.99
    for _ in range(48):
        mid = (lo + hi) / 2
        ok = cr(from_lch(mid, C, H), against) >= need
        if light_ground:          # passing region is L <= L*, want the largest
            lo, hi = (mid, hi) if ok else (lo, mid)
        else:                     # passing region is L >= L*, want the smallest
            lo, hi = (lo, mid) if ok else (mid, hi)
    return lo if light_ground else hi


WASH = 0.10          # the alpha behind every status tag

# ---------------------------------------------------------------- anchors
GOLD = "#B8860B"          # the one gold that appears in the product
GOLD_BRIGHT = "#E8B84B"   # gradient only, never a UI fill
GOLD_WARM = "#C8961E"     # gradient only
BEIGE = "#F0E8DA"
INK = "#2B1B14"

# The gold and the beige turn out to sit on the SAME Oklch hue: 81.6 and 81.8
# degrees. That is the whole system in one fact. The paper and the metal are one
# hue at different lightness, so the neutral ramp is built on that hue and every
# surface in the product is quietly related to the logo.
NEUTRAL_H = (lch(GOLD)[2] + lch(BEIGE)[2]) / 2.0

# Lightness stops, even in Oklab L. Step 10 IS the brand beige, to four decimal
# places. Chroma tapers at the light end so paper stays paper.
STEPS = [
    ("00", 0.985, 0.008), ("05", 0.958, 0.014), ("10", 0.933, 0.0206),
    ("20", 0.880, 0.026), ("30", 0.800, 0.030), ("40", 0.700, 0.032),
    ("50", 0.600, 0.032), ("60", 0.500, 0.032), ("70", 0.400, 0.030),
    ("80", 0.310, 0.030), ("90", 0.241, 0.028), ("95", 0.180, 0.026),
]
SAND = {k: from_lch(L, C, NEUTRAL_H) for k, L, C in STEPS}

# Semantic hues, rotated off the gold rather than imported from a framework.
_gL, _gC, _gH = lch(GOLD)
# Status hues, rotated off the gold. Lightness is SOLVED against the flattened
# wash the tag actually sits on, not against the bare surface. Measuring against
# the surface overstates every one of these by roughly half a point.
_HUES = {
    "verified": _gH + 0.62,      # olive, a short rotation toward green
    "partial":  _gH,             # the brand gold itself
    "risk":     _gH - 0.72,      # terracotta, rotated the other way
    "info":     _gH + 2.55,      # a slate, kept low in chroma so it is never
}                                # mistaken for the framework blue
_CHROMA = {"verified": 0.072, "partial": 0.105, "risk": 0.130, "info": 0.055}


def _status(name, surface, light_ground):
    """Solve so the tag text clears 4.5:1 on its OWN 10 percent wash over
    `surface`. Measuring against the bare surface overstates every one of these,
    because the wash the tag paints behind itself moves the ground."""
    C, H = _CHROMA[name], _HUES[name]
    need = 4.5 * 1.03
    lo, hi = 0.02, 0.99
    for _ in range(48):
        mid = (lo + hi) / 2
        c = from_lch(mid, C, H)
        ok = cr(c, composite(c, surface, WASH)) >= need
        if light_ground:
            lo, hi = (mid, hi) if ok else (lo, mid)
        else:
            lo, hi = (lo, mid) if ok else (mid, hi)
    return from_lch(lo if light_ground else hi, C, H)


SEM = {}
for _n in ("verified", "partial", "risk", "info"):
    SEM[_n] = _status(_n, "#FDFAF4", True)
    SEM[_n + "_dk"] = _status(_n, "#261E10", False)

# ---------------------------------------------------------------- roles
_ON_LIGHT = SAND["00"]
# A filled gold button must carry text at 4.5:1, which #B8860B cannot. Solve for
# the lightest gold that can.
_ACCENT_SOLID_L = solve_L(0.108, _gH, _ON_LIGHT, 4.5)
_FOCUS_L = solve_L(0.110, _gH, SAND["05"], 3.0)

LIGHT = {
    "canvas":     SAND["05"],
    "surface":    SAND["00"],
    "surface-2":  SAND["10"],
    "surface-3":  SAND["20"],
    "line":       SAND["30"],
    "line-strong": SAND["40"],
    "text":       SAND["95"],
    "text-2":     SAND["70"],
    "text-3":     SAND["60"],
    "accent":     GOLD,
    "accent-text": from_lch(0.520, 0.108, _gH),
    "accent-solid": from_lch(_ACCENT_SOLID_L, 0.108, _gH),
    "on-accent":  _ON_LIGHT,
    "focus":      from_lch(_FOCUS_L, 0.110, _gH),
}
DARK = {
    "canvas":     SAND["95"],
    "surface":    SAND["90"],
    "surface-2":  SAND["80"],
    "surface-3":  SAND["70"],
    "line":       SAND["70"],
    "line-strong": SAND["60"],
    "text":       SAND["05"],
    "text-2":     SAND["30"],
    "text-3":     SAND["40"],
    "accent":     GOLD_BRIGHT,
    "accent-text": from_lch(0.800, 0.100, _gH),
    "accent-solid": GOLD_BRIGHT,
    "on-accent":  SAND["95"],
    "focus":      from_lch(0.800, 0.100, _gH),
}

# Pairings that must pass. (foreground, background, minimum ratio, why)
CHECKS = [
    ("text", "canvas", 7.0, "body text"),
    ("text", "surface", 7.0, "body text on a card"),
    ("text-2", "canvas", 4.5, "secondary text"),
    ("text-2", "surface", 4.5, "secondary text on a card"),
    ("text-3", "canvas", 3.0, "micro labels, 11px uppercase"),
    ("accent-text", "canvas", 4.5, "gold used as text"),
    ("accent-text", "surface", 4.5, "gold used as text on a card"),
    ("line", "canvas", 1.3, "hairline must be visible but quiet"),
    ("on-accent", "accent-solid", 4.5, "label on a filled gold button"),
    ("focus", "canvas", 3.0, "focus ring, WCAG 2.2 non-text contrast"),
    ("focus", "surface", 3.0, "focus ring on a card"),
]


def audit():
    rows = []
    for mode, roles in (("light", LIGHT), ("dark", DARK)):
        for fg, bg, minimum, why in CHECKS:
            r = cr(roles[fg], roles[bg])
            rows.append(dict(mode=mode, fg=fg, bg=bg, hex_fg=roles[fg], hex_bg=roles[bg],
                             ratio=round(r, 2), minimum=minimum, pass_=r >= minimum, why=why))
    for mode, roles in (("light", LIGHT), ("dark", DARK)):
        for name in ("verified", "partial", "risk", "info"):
            k = name if mode == "light" else name + "_dk"
            bgc = composite(SEM[k], roles["surface"], WASH)
            r = cr(SEM[k], bgc)
            rows.append(dict(mode=mode, fg=k, bg="its own wash", hex_fg=SEM[k], hex_bg=bgc,
                             ratio=round(r, 2), minimum=4.5, pass_=r >= 4.5,
                             why=f"{name} tag text on its 10 percent wash"))
    return rows


if __name__ == "__main__":
    rows = audit()
    bad = [r for r in rows if not r["pass_"]]
    for r in rows:
        print("%-6s %-12s on %-10s %6.2f:1  min %.1f  %s   %s" %
              (r["mode"], r["fg"], r["bg"], r["ratio"], r["minimum"],
               "ok " if r["pass_"] else "FAIL", r["why"]))
    print("\nsand ramp"); [print(" ", k, v) for k, v in SAND.items()]
    print("semantic"); [print(" ", k, v) for k, v in SEM.items()]
    print("\n%d checks, %d failures" % (len(rows), len(bad)))
    json.dump(dict(sand=SAND, sem=SEM, light=LIGHT, dark=DARK, audit=rows),
              open("palette.json", "w"), indent=1)
