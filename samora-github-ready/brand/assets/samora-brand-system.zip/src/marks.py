"""Logo lockups rebuilt on the single brand family.

The mark geometry is untouched. Only the wordmark and tagline move from Jost to
Archivo, so the identity is genuinely one family across mark, product and print.
Archivo is set at 400 with tracking 215 and matched to the previous CAP HEIGHT,
not the previous width, so the lockup's optical weight is unchanged.
"""
import sys, os
sys.path.insert(0, "/home/claude/logo")
os.chdir("/home/claude/logo")
import final as F
from typeset import typeset, metrics

FAM, WT, TRACK = "archivo", 400, 215
TAG_TRACK = 210.0
TAG = F.TAG
GRAD_ID = "sg"


def ink(t, f, w, s, tr, x0=0.0, b=0.0):
    return typeset(t, f, w, s, tr, 0.0, b, x0)


def _width(t, f, w, s, tr):
    _, _, (a0, _, a1, _) = ink(t, f, w, s, tr)
    return a1 - a0


def _solve(t, f, w, tr, target):
    lo, hi = 1.0, 600.0
    for _ in range(60):
        mid = (lo + hi) / 2
        if _width(t, f, w, mid, tr) < target:
            lo = mid
        else:
            hi = mid
    return lo


def _mark(grad):
    return (f'<circle cx="0" cy="0" r="{F.R_OUT - F.BAND/2:.2f}" fill="none" '
            f'stroke="{grad}" stroke-width="{F.BAND:.2f}"/>'
            f'<path d="{F.d_of(F.PTS)}" fill="none" stroke="{grad}" '
            f'stroke-width="{F.SW:.2f}" stroke-linecap="butt" stroke-linejoin="miter" '
            f'stroke-miterlimit="{F.MITER}"/>')


def lockup(grad=f"url(#{GRAD_ID})"):
    """Stacked lockup: mark, SAMORA, tagline. Returns (body, box)."""
    bx0, by0, bx1, by1 = F.BADGE_BOX
    BW = bx1 - bx0
    # cap height carried over from the Jost build so nothing changes optically
    jost_size = _solve("SAMORA", "jost", 500, 170, 0.86 * BW)
    mj = metrics("jost", 500)
    cap = mj["cap"] / mj["upm"] * jost_size
    m = metrics(FAM, WT)
    ws = cap * m["upm"] / m["cap"]
    word_w = _width("SAMORA", FAM, WT, ws, TRACK)
    ts = _solve(TAG, FAM, 400, TAG_TRACK, word_w)
    m4 = metrics(FAM, 400)
    tc = m4["cap"] / m4["upm"] * ts
    wby = by1 + 0.11 * BW + cap
    tby = wby + 0.74 * cap + tc
    _, _, (a0, _, a1, _) = ink("SAMORA", FAM, WT, ws, TRACK)
    wd, _, wb = ink("SAMORA", FAM, WT, ws, TRACK, -(a1 - a0) / 2 - a0, wby)
    _, _, (t0, _, t1, _) = ink(TAG, FAM, 400, ts, TAG_TRACK)
    td, _, tb = ink(TAG, FAM, 400, ts, TAG_TRACK, -(t1 - t0) / 2 - t0, tby)
    body = _mark(grad) + f'<path d="{wd}" fill="{grad}"/><path d="{td}" fill="{grad}"/>'
    return body, (min(bx0, wb[0], tb[0]), by0, max(bx1, wb[2], tb[2]), tb[3])


def badge(grad=f"url(#{GRAD_ID})"):
    return _mark(grad), F.BADGE_BOX


def horizontal(grad=f"url(#{GRAD_ID})"):
    """Mark left, SAMORA over the tagline to its right, left aligned."""
    bx0, by0, bx1, by1 = F.BADGE_BOX
    h = by1 - by0
    gap = h * 0.20
    cap = h * 0.255
    m = metrics(FAM, WT)
    ws = cap * m["upm"] / m["cap"]
    word_w = _width("SAMORA", FAM, WT, ws, TRACK)
    ts = _solve(TAG, FAM, 400, TAG_TRACK, word_w)
    m4 = metrics(FAM, 400)
    tc = m4["cap"] / m4["upm"] * ts
    x = (bx1 - bx0) + gap
    wbase = (h + cap - tc * 2.95) / 2.0
    tbase = wbase + tc * 2.95
    _, _, (a0, *_r) = ink("SAMORA", FAM, WT, ws, TRACK)
    wd, _, wb = ink("SAMORA", FAM, WT, ws, TRACK, x - a0, wbase)
    _, _, (t0, *_s) = ink(TAG, FAM, 400, ts, TAG_TRACK)
    td, _, tb = ink(TAG, FAM, 400, ts, TAG_TRACK, x - t0, tbase)
    body = (f'<g transform="translate({-bx0:.2f},{-by0:.2f})">{_mark(grad)}</g>'
            f'<path d="{wd}" fill="{grad}"/><path d="{td}" fill="{grad}"/>')
    return body, (0, 0, max(bx1 - bx0, wb[2], tb[2]), max(h, tb[3]))


def gradient(box, deep="#B8860B", bright="#E8B84B", warm="#C8961E"):
    return (f'<linearGradient id="{GRAD_ID}" gradientUnits="userSpaceOnUse" '
            f'x1="{box[0]:.1f}" y1="{box[1]:.1f}" x2="{box[2]:.1f}" y2="{box[3]:.1f}">'
            f'<stop offset="0%" stop-color="{deep}"/><stop offset="45%" stop-color="{bright}"/>'
            f'<stop offset="100%" stop-color="{warm}"/></linearGradient>')


def svg(kind="lockup", ground=None, pad=0.09, flat=None):
    fn = {"lockup": lockup, "badge": badge, "horizontal": horizontal}[kind]
    grad = flat if flat else f"url(#{GRAD_ID})"
    body, box = fn(grad)
    x0, y0, x1, y1 = box
    q = max(x1 - x0, y1 - y0) * pad
    vx, vy, vw, vh = x0 - q, y0 - q, (x1 - x0) + 2 * q, (y1 - y0) + 2 * q
    defs = "" if flat else f"<defs>{gradient(box)}</defs>"
    bg = (f'<rect x="{vx:.2f}" y="{vy:.2f}" width="{vw:.2f}" height="{vh:.2f}" fill="{ground}"/>'
          if ground else "")
    return (f'<svg xmlns="http://www.w3.org/2000/svg" viewBox="{vx:.2f} {vy:.2f} {vw:.2f} {vh:.2f}" '
            f'width="{vw:.0f}" height="{vh:.0f}">{defs}{bg}{body}</svg>')


if __name__ == "__main__":
    import cairosvg
    out = "/home/claude/brand/marks"
    os.makedirs(out, exist_ok=True)
    jobs = {
        "samora-lockup":             svg("lockup", "#F0E8DA"),
        "samora-lockup-transparent": svg("lockup", None),
        "samora-lockup-reversed":    svg("lockup", "#2B1B14"),
        "samora-lockup-flat":        svg("lockup", None, flat="#B8860B"),
        "samora-horizontal":         svg("horizontal", "#F0E8DA", 0.10),
        "samora-horizontal-transparent": svg("horizontal", None, 0.10),
        "samora-badge":              svg("badge", "#F0E8DA", 0.05),
        "samora-badge-transparent":  svg("badge", None, 0.05),
        "samora-badge-reversed":     svg("badge", "#2B1B14", 0.05),
        "samora-badge-flat":         svg("badge", None, 0.05, flat="#B8860B"),
    }
    for n, s in jobs.items():
        open(f"{out}/{n}.svg", "w").write(s)
        cairosvg.svg2png(bytestring=s.encode(), write_to=f"{out}/{n}.png", output_width=1600)
    print("wrote", len(jobs) * 2, "files to", out)
