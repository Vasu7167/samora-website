"""Before and after: the same panel, current stylesheet versus the new system.

The BEFORE side is not a caricature. Every value in it was read out of
engineering/repo/index.html: the golds, the surfaces, the 20px pills, the
emoji, the DM Sans and EB Garamond pairing, the transition: all.
"""
import base64
NM = "/home/claude/logo/node_modules"


def face(fam, path, w):
    b = base64.b64encode(open(path, "rb").read()).decode()
    return (f"@font-face{{font-family:'{fam}';font-weight:{w};font-style:normal;"
            f"src:url(data:font/woff2;base64,{b}) format('woff2');}}")


FACES = "".join([
    face("Archivo", f"{NM}/@fontsource/archivo/files/archivo-latin-{w}-normal.woff2", w)
    for w in (400, 500, 600)] + [
    face("DM Sans", f"{NM}/@fontsource/dm-sans/files/dm-sans-latin-{w}-normal.woff2", w)
    for w in (400, 500)])

TOKENS = open("/home/claude/brand/samora-tokens.css").read()

BEFORE = """
<div class="old">
  <div class="o-head">
    <div class="o-title">⚡ Pipeline Health</div>
    <div class="o-pills">
      <span class="o-pill o-super">🟣 Admin</span>
      <span class="o-pill o-org">🏢 Samora Global</span>
      <span class="o-pill o-date">🕐 Today</span>
    </div>
  </div>
  <div class="o-cards">
    <div class="o-card"><div class="o-k">💰 Verified Pipeline</div>
      <div class="o-v">1,735,500</div><div class="o-d">📈 62% of total, up from 54</div></div>
    <div class="o-card"><div class="o-k">⚠️ Deals At Risk</div>
      <div class="o-v">7</div><div class="o-d">⏳ Single threaded 21+ days</div></div>
    <div class="o-card"><div class="o-k">🎯 Coverage</div>
      <div class="o-v">2.4x</div><div class="o-bar"><span></span></div></div>
  </div>
  <table class="o-tbl">
    <tr><th>Account</th><th>Tier</th><th>Health</th><th>Value</th></tr>
    <tr><td>Acme Manufacturing</td><td><span class="o-tag o-ok">✅ Verified</span></td>
      <td>82</td><td>1,180,000</td></tr>
    <tr><td>Northgate Logistics</td><td><span class="o-tag o-mid">⚠️ Partial</span></td>
      <td>61</td><td>465,500</td></tr>
    <tr><td>Illinois Bell Holdings</td><td><span class="o-tag o-bad">🔴 At Risk</span></td>
      <td>38</td><td>90,000</td></tr>
  </table>
  <div class="o-btns">
    <button class="o-btn o-primary">🚀 Verify Pipeline</button>
    <button class="o-btn">📋 Export</button>
    <button class="o-btn o-ghost">Cancel</button>
  </div>
</div>"""

AFTER = """
<div class="new" data-theme="dark">
  <div class="n-head">
    <div class="n-title">Pipeline health</div>
    <div class="row">
      <span class="tag tag--neutral">Admin</span>
      <span class="tag tag--neutral">Samora Global</span>
      <span class="tag tag--neutral">Today</span>
    </div>
  </div>
  <div class="n-cards">
    <div class="kpi"><div class="k">Verified pipeline</div><div class="v">1,735,500</div>
      <div class="d">62 percent of total, up from 54</div></div>
    <div class="kpi"><div class="k">Deals at risk</div><div class="v">7</div>
      <div class="d">Single threaded for over 21 days</div></div>
    <div class="kpi"><div class="k">Coverage</div><div class="v">2.4&times;</div>
      <div class="meter" style="margin-top:10px"><i style="width:60%"></i></div></div>
  </div>
  <table class="table">
    <thead><tr><th>Account</th><th>Tier</th><th class="num">Health</th><th class="num">Value</th></tr></thead>
    <tbody>
      <tr><td>Acme Manufacturing</td><td><span class="tag tag--verified">Verified</span></td>
        <td class="num">82</td><td class="num">1,180,000</td></tr>
      <tr><td>Northgate Logistics</td><td><span class="tag tag--partial">Partial</span></td>
        <td class="num">61</td><td class="num">465,500</td></tr>
      <tr><td>Illinois Bell Holdings</td><td><span class="tag tag--risk">At risk</span></td>
        <td class="num">38</td><td class="num">90,000</td></tr>
    </tbody>
  </table>
  <div class="row" style="margin-top:var(--s-5)">
    <button class="btn btn--primary">Verify pipeline</button>
    <button class="btn">Export</button>
    <button class="btn btn--quiet">Cancel</button>
  </div>
</div>"""

CSS = TOKENS + """
body{background:var(--c-canvas);padding:34px 30px;}
.wrap{display:grid;grid-template-columns:1fr 1fr;gap:26px;max-width:1520px;margin:0 auto;}
.lab{font-size:var(--t-3xs);font-weight:var(--w-semibold);letter-spacing:var(--track-caps);
     text-transform:uppercase;margin:0 0 10px 2px;}
.lab.a{color:var(--c-risk);} .lab.b{color:var(--c-verified);}
.note{font-size:var(--t-2xs);color:var(--c-text-2);margin:12px 2px 0;line-height:1.6;}
.row{display:flex;gap:var(--s-2);align-items:center;flex-wrap:wrap;}

/* ---------- BEFORE: values lifted verbatim from index.html ---------- */
.old{background:#18160F;border-radius:14px;padding:22px 22px 20px;
     font-family:'DM Sans',sans-serif;color:#FAF8F4;font-size:17px;line-height:1.6;}
.o-head{display:flex;justify-content:space-between;align-items:flex-start;gap:12px;
        padding-bottom:16px;border-bottom:1px solid rgba(201,151,62,0.12);margin-bottom:18px;}
.o-title{font-family:'DM Sans',sans-serif;font-size:28px;line-height:1.15;}
.o-pills{display:flex;gap:6px;flex-wrap:wrap;}
.o-pill{font-size:11px;border-radius:20px;padding:3px 10px;}
.o-super{background:rgba(167,139,250,0.15);color:#A0752A;}
.o-org{background:#2C2720;border:1px solid rgba(201,151,62,0.12);color:#6B6459;}
.o-date{background:#2C2720;border:1px solid rgba(201,151,62,0.25);color:#C4BAA8;}
.o-cards{display:grid;grid-template-columns:repeat(3,1fr);gap:10px;margin-bottom:18px;}
.o-card{background:#231F17;border:1px solid rgba(201,151,62,0.25);border-radius:12px;padding:14px;
        box-shadow:0 4px 12px rgba(0,0,0,0.4);}
.o-k{font-size:12px;color:#C4BAA8;}
.o-v{font-size:32px;font-weight:500;margin-top:4px;}
.o-d{font-size:11px;color:#6B6459;margin-top:5px;}
.o-bar{height:3px;background:#2C2720;border-radius:2px;overflow:hidden;margin-top:12px;}
.o-bar span{display:block;height:100%;width:60%;
  background:linear-gradient(90deg,#A0752A,#C9973E,#E8C97A);border-radius:2px;}
.o-tbl{width:100%;border-collapse:collapse;font-size:13px;}
.o-tbl th{text-align:left;font-size:10px;color:#6B6459;padding:0 8px 6px 0;
          border-bottom:1px solid rgba(201,151,62,0.12);}
.o-tbl td{padding:9px 8px 9px 0;border-bottom:1px solid rgba(201,151,62,0.12);font-size:13px;}
.o-tag{font-size:11px;border-radius:20px;padding:3px 10px;white-space:nowrap;}
.o-ok{background:rgba(110,231,183,0.1);color:#4A8C5C;}
.o-mid{background:rgba(251,191,36,0.12);color:#C9973E;}
.o-bad{background:rgba(251,124,107,0.1);color:#C0523F;}
.o-btns{display:flex;gap:8px;margin-top:18px;flex-wrap:wrap;}
.o-btn{border-radius:8px;padding:10px 16px;font-family:'DM Sans',sans-serif;font-size:14px;
       background:#2C2720;border:1px solid rgba(201,151,62,0.25);color:#FAF8F4;cursor:pointer;
       transition:all 0.2s;}
.o-primary{background:linear-gradient(135deg,#A0752A,#C9973E);border:none;color:#18160F;
           font-weight:500;box-shadow:0 4px 16px rgba(184,134,11,0.45),0 2px 5px rgba(0,0,0,0.25);}
.o-ghost{background:none;border:1px solid rgba(201,151,62,0.12);color:#6B6459;border-radius:20px;}

/* ---------- AFTER ---------- */
.new{background:var(--c-canvas);border:var(--line-w) solid var(--c-line);
     border-radius:var(--r-md);padding:var(--s-5);color:var(--c-text);}
.n-head{display:flex;justify-content:space-between;align-items:flex-start;gap:var(--s-3);
        padding-bottom:var(--s-4);border-bottom:var(--line-w) solid var(--c-line);
        margin-bottom:var(--s-5);}
.n-title{font-size:var(--t-xl);font-weight:var(--w-semibold);letter-spacing:var(--track-display);
         line-height:var(--lh-tight);}
.n-cards{display:grid;grid-template-columns:repeat(3,1fr);gap:var(--s-3);margin-bottom:var(--s-5);}
.kpi{background:var(--c-surface);border:var(--line-w) solid var(--c-line);
     border-radius:var(--r-md);padding:var(--s-4);}
.kpi .k{font-size:var(--t-3xs);font-weight:var(--w-semibold);letter-spacing:var(--track-caps);
        text-transform:uppercase;color:var(--c-text-3);}
.kpi .v{font-size:var(--t-2xl);font-weight:var(--w-semibold);line-height:var(--lh-tight);
        margin-top:6px;letter-spacing:var(--track-display);color:var(--c-text);}
.kpi .d{font-size:var(--t-2xs);color:var(--c-text-2);margin-top:4px;}
"""

HTML = f"""<!DOCTYPE html><html data-theme="dark"><head><meta charset="utf-8">
<style>{FACES}</style><style>{CSS}</style></head><body><div class="wrap">
<div><div class="lab a">Before &nbsp;/&nbsp; today's stylesheet, values unchanged</div>{BEFORE}
  <div class="note">Nine emoji. Six corner radii. Four type sizes in the cards alone. A gradient
  button with a coloured drop shadow. Pills for everything. Two golds, neither of them the
  brand gold. A violet wash left over from a component library.</div></div>
<div><div class="lab b">After &nbsp;/&nbsp; the same panel on the token system</div>{AFTER}
  <div class="note">No emoji. Two radii. One family, three weights. Flat brand gold, solved so the
  label on it clears 4.5:1. Status is a rectangle with a hairline. Borders separate things,
  shadows do not.</div></div>
</div></body></html>"""

if __name__ == "__main__":
    open("/home/claude/brand/compare.html", "w").write(HTML)
    print("wrote compare.html")
