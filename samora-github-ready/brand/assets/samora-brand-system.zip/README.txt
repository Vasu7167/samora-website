SAMORA BRAND SYSTEM  v1.0

START HERE
  samora-brand-book.html    open in a browser. Live components, not screenshots.
  samora-brand-book.pdf     the same content, sendable and printable, 19 pages.
  samora-tokens.css         the drop-in. Replaces the :root block in index.html.
  before-after.png          the same panel, today's stylesheet beside the new one.

WHAT CHANGED, IN ONE LINE
  One typeface (Archivo), twelve neutrals on a single hue, two corner radii,
  one border width, two motion durations, and no emoji.

THE MEASUREMENT THE SYSTEM IS BUILT ON
  The brand gold #B8860B and the brand beige #F0E8DA sit on the same Oklch hue,
  81.57 and 81.78 degrees. Every neutral in the product is that hue at a
  different lightness, which is why the interface relates to the logo without
  repeating it.

TYPEFACE
  Archivo, weights 400, 500 and 600 only.
  fonts/ holds the three woff2 files. Self host them, do not hotlink.
  Also on Google Fonts if you would rather link it.
  Archivo now sets the wordmark too, so mark, product and print are one family.
  Email is the single exception: no client loads webfonts reliably, so the
  signature falls back to Helvetica and Arial after Archivo.

MARKS
  marks/  the lockups rebuilt on Archivo. Stacked, horizontal and badge, each in
          beige, reversed, transparent and flat gold. SVG and PNG.

APPLICATIONS
  applications/samora-letterhead-*      A4, SVG PDF and PNG
  applications/samora-li-logo-*         LinkedIn page logo, 400x400
  applications/samora-li-cover-*        LinkedIn cover, 1128x191 at 2x
  applications/signature*.html          email signature

ADOPTING THE TOKENS
  1. Load Archivo 400, 500, 600. Nothing else.
  2. Paste samora-tokens.css over the current :root and theme blocks.
  3. Apply the mapping table in section 11 of the book.
  4. Delete every emoji in the markup.
  5. Search for  #  and  rgba(  outside the token file. Every hit is a bug.
  6. Search for  transition:all  and name the properties.
  7. Search for  border-radius  and reduce to var(--r-sm) or var(--r-md).

  Two things worth knowing before you paste:
    --c-accent is the display gold. It measures 3.1:1 behind text, so it can
    never be a filled button. Use --c-accent-solid for that, which is solved
    for 4.5:1 against --c-on-accent.
    Status colours are solved against their own ten percent wash, not against
    the bare card, because the wash is what the text actually sits on.

SOURCE
  src/palette.py       generates the colour and runs the contrast audit.
                       Run it: 30 checks, 0 failures.
  src/gen_tokens.py    emits samora-tokens.css from the palette.
  src/marks.py         emits the lockups.
  src/applications.py  emits the letterhead and LinkedIn assets.
  src/book.py          emits the brand book.
  src/compare.py       emits before-after.png.

  Build order matters: palette.py, then gen_tokens.py, then book.py.
  The book embeds the token file, so it has to be rebuilt after the tokens.

  Nothing in this system is hand picked. If you need to change a colour,
  change the anchor in palette.py and regenerate. That is the point.
